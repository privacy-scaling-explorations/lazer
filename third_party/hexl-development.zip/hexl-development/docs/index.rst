.. Copyright (C) 2020 Intel Corporation
.. SPDX-License-Identifier: Apache-2.0


Intel HEXL Documentation
==============================

.. toctree::
   api

.. mdinclude:: ../README.md
