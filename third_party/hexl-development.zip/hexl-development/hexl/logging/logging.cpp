// Copyright (C) 2020 Intel Corporation
// SPDX-License-Identifier: Apache-2.0

#include "hexl/logging/logging.hpp"

#ifdef HEXL_DEBUG
INITIALIZE_EASYLOGGINGPP
#endif
